// 日本メーカーフィルター — Amazon の検索結果で日本メーカー品を強調する拡張機能の本体
// ON/OFF と表示方法（薄く表示 / 非表示）はツールバーアイコンの設定パネルから切り替える。
// 設定は chrome.storage.local に保存し、変更を監視して即座に反映する。

(function () {
  'use strict';

  // ===== 既定の設定 ===============================================
  const DEFAULTS = { enabled: true, mode: 'badge' }; // mode: 'badge'（薄く表示＋印） / 'hide'（非表示）
  let enabled = DEFAULTS.enabled;
  let mode = DEFAULTS.mode;

  const DIM_OPACITY = '0.3';           // 薄く表示するときの濃さ（0=透明〜1=通常）
  const OBSERVER_DEBOUNCE_MS = 300;    // 画面更新時に再判定するまでの待ち時間
  const PROCESSED_FLAG = 'yamatoFilterDone'; // 二重処理を防ぐ目印（dataset キー）

  // ===== 日本メーカー定義 ==========================================
  // jp: カナ・漢字表記（タイトルに「含まれていれば」一致と見なす）
  // en: 英字表記（タイトル中で「独立した単語として」一致したときだけ採用）
  //   ※ 英字は単語境界で照合するため connect の中の "nec" 等には誤反応しない。
  //   ※ "mouse" "final" "リズム" 等のありふれた語は誤検出が多いため、正確形で照合する。
  // リストはここに足す・消すだけで調整できる。
  const JP_MAKERS = [
    { jp: ['ソニー'], en: ['SONY', 'WALKMAN', 'BRAVIA'] },
    { jp: ['パナソニック'], en: ['Panasonic'] },
    { jp: ['シャープ'], en: ['SHARP'] },
    { jp: ['東芝', 'レグザ'], en: ['TOSHIBA', 'REGZA', 'dynabook'] },
    { jp: ['日立'], en: ['HITACHI'] },
    { jp: ['三菱電機', '三菱'], en: [] },
    { jp: ['富士通'], en: ['FUJITSU', 'FMV'] },
    { jp: ['エヌイーシー'], en: ['NEC', 'LAVIE'] },
    { jp: ['ジェイブイシーケンウッド', 'ケンウッド', 'ビクター'], en: ['JVC', 'Kenwood'] },
    { jp: ['パイオニア'], en: ['Pioneer'] },
    { jp: ['オンキヨー', 'オンキョー'], en: ['ONKYO'] },
    { jp: ['デノン'], en: ['DENON'] },
    { jp: ['マランツ'], en: ['Marantz'] },
    { jp: ['ヤマハ'], en: ['YAMAHA'] },
    { jp: ['オーディオテクニカ', 'オーディオ テクニカ'], en: ['audio-technica'] },
    { jp: ['エイビオット'], en: ['AVIOT'] },
    { jp: ['ローランド'], en: ['Roland'] },
    { jp: ['コルグ'], en: ['KORG'] },
    { jp: ['ティアック'], en: ['TEAC'] },
    { jp: ['フォステクス'], en: ['FOSTEX'] },
    { jp: ['キヤノン', 'キャノン'], en: ['Canon'] },
    { jp: ['ニコン'], en: ['Nikon'] },
    { jp: ['富士フイルム', '富士フィルム'], en: ['FUJIFILM'] },
    { jp: ['リコー'], en: ['RICOH'] },
    { jp: ['ペンタックス'], en: ['PENTAX'] },
    { jp: ['オリンパス'], en: ['OLYMPUS', 'OM SYSTEM'] },
    { jp: ['シグマ'], en: ['SIGMA'] },
    { jp: ['タムロン'], en: ['TAMRON'] },
    { jp: ['ケンコー'], en: ['Kenko'] },
    { jp: ['カシオ'], en: ['CASIO'] },
    { jp: ['セイコー'], en: ['SEIKO'] },
    { jp: ['シチズン'], en: ['CITIZEN'] },
    { jp: ['エレコム'], en: ['ELECOM'] },
    { jp: ['バッファロー'], en: ['BUFFALO'] },
    { jp: ['アイオーデータ', 'アイ・オー・データ'], en: ['IODATA', 'I-O DATA'] },
    { jp: ['サンワサプライ', 'サンワ'], en: [] },
    { jp: ['ロジテック'], en: ['Logitec'] }, // 日本のロジテック（スイスの Logitech とは別会社）
    { jp: ['エプソン', 'セイコーエプソン'], en: ['EPSON'] },
    { jp: ['ブラザー'], en: ['brother'] },
    { jp: ['京セラ'], en: ['KYOCERA'] },
    { jp: ['アイリスオーヤマ'], en: ['IRIS OHYAMA', 'IRIS'] },
    { jp: ['象印', 'ゾウジルシ'], en: ['ZOJIRUSHI'] },
    { jp: ['ハリオ'], en: ['HARIO'] },
    { jp: ['タイガー魔法瓶', 'タイガー'], en: ['TIGER'] },
    { jp: ['ツインバード'], en: ['TWINBIRD'] },
    { jp: ['バルミューダ'], en: ['BALMUDA'] },
    { jp: ['山善'], en: ['YAMAZEN'] },
    { jp: ['コイズミ'], en: ['KOIZUMI'] },
    { jp: ['テスコム'], en: ['TESCOM'] },
    { jp: ['シロカ'], en: ['siroca'] },
    { jp: ['ドウシシャ'], en: [] },
    { jp: ['リズム(RHYTHM)', 'リズム(Rhythm)', 'リズム時計'], en: [] }, // 「リズム」単体は音楽系に誤反応するため正確形で照合
    { jp: ['フランフラン', 'Francfranc'], en: [] },
    { jp: ['マクセル'], en: ['maxell'] },
    { jp: ['村田製作所'], en: ['Murata'] },
    { jp: ['ティーディーケイ'], en: ['TDK'] },
    { jp: ['任天堂'], en: ['Nintendo'] },

    // ===== 辞書拡充（誤検出ゼロ優先） ===============================
    // 方針：英字は「final / mouse / max」等のありふれた単語を避け、
    //       カナは「コロナ / グリーンハウス（＝温室）」等の衝突語を避ける。
    //       国籍が曖昧なブランド（Marantz等の外国発祥）は入れない。
    // --- AV・音響 ---
    { jp: ['ラックスマン'], en: ['LUXMAN'] },
    { jp: ['アキュフェーズ'], en: ['Accuphase'] },
    { jp: ['ラディウス'], en: [] }, // radius は英単語と衝突するためカナのみ
    { jp: ['カロッツェリア'], en: ['carrozzeria'] }, // パイオニアのカーAV
    // --- カメラ・光学 ---
    { jp: ['ハクバ'], en: ['HAKUBA'] },
    { jp: ['ベルボン'], en: ['Velbon'] },
    { jp: ['スリック'], en: ['SLIK'] },
    { jp: ['エツミ'], en: ['Etsumi'] },
    { jp: ['コシナ'], en: ['Cosina'] },
    { jp: ['ニッシン'], en: ['Nissin'] }, // ストロボ。日清食品にも当たるが両方日本企業なので可
    // --- PC・周辺機器 ---
    { jp: ['ブイエイオー'], en: ['VAIO'] },
    { jp: ['マウスコンピューター'], en: ['mouse computer'] }, // 単語 mouse は避け二語句で照合
    { jp: ['プリンストン'], en: ['Princeton'] },
    { jp: ['センチュリー'], en: [] },
    { jp: ['アーキサイト'], en: ['ARCHISS'] },
    { jp: ['東プレ', 'リアルフォース'], en: ['REALFORCE', 'Topre'] },
    { jp: ['ダイヤテック', 'フィルコ'], en: ['FILCO'] },
    { jp: ['ナカバヤシ'], en: ['Nakabayashi'] },
    // --- 生活家電・空調・暖房 ---
    { jp: ['ダイキン'], en: ['DAIKIN'] },
    { jp: ['ダイニチ'], en: ['Dainichi'] },
    { jp: ['トヨトミ'], en: ['TOYOTOMI'] },
    { jp: ['ノーリツ'], en: ['Noritz'] },
    { jp: ['リンナイ'], en: ['Rinnai'] },
    { jp: ['パロマ'], en: [] },
    { jp: ['ニトリ'], en: [] },
    { jp: ['無印良品'], en: ['MUJI'] },
    // --- 調理・キッチン ---
    { jp: ['貝印'], en: [] },
    { jp: ['パール金属'], en: [] },
    { jp: ['和平フレイズ'], en: [] },
    { jp: ['下村工業'], en: [] },
    // --- 美容・健康家電 ---
    { jp: ['ヤーマン'], en: ['YA-MAN'] },
    { jp: [], en: ['ReFa'] }, // カナ「リファ」はリファレンス等と衝突するため英字のみ
    { jp: ['サロニア'], en: ['SALONIA'] },
    { jp: ['ドリテック'], en: ['dretec'] },
    // --- 電動工具・作業用品 ---
    { jp: ['マキタ'], en: ['MAKITA'] },
    { jp: ['ハイコーキ', '工機ホールディングス'], en: ['HiKOKI'] },
    { jp: ['リョービ'], en: ['RYOBI'] },
    { jp: ['ベッセル'], en: [] },
    { jp: ['トラスコ'], en: ['TRUSCO'] },
    { jp: ['タジマ'], en: ['Tajima'] },
    { jp: ['京都機械工具'], en: ['KTC'] },
    // --- 計測・健康機器 ---
    { jp: ['オムロン'], en: ['OMRON'] },
    { jp: ['タニタ'], en: ['TANITA'] },
    { jp: ['テルモ'], en: ['Terumo'] },
    // --- カー用品・電装 ---
    { jp: ['ユピテル'], en: ['YUPITERU'] },
    { jp: ['コムテック'], en: ['COMTEC'] },
    { jp: ['デンソー'], en: ['DENSO'] },
    { jp: ['ブリヂストン'], en: ['BRIDGESTONE'] },
    // --- 電池・電子部品 ---
    { jp: ['太陽誘電'], en: ['Taiyo Yuden'] },
    { jp: ['ユアサ'], en: [] },
    { jp: ['エネループ'], en: ['eneloop'] },
    { jp: ['エフディーケイ'], en: ['FDK'] },
    // --- ゲーム・玩具 ---
    { jp: ['バンダイ'], en: ['BANDAI'] },
    { jp: ['タカラトミー'], en: [] },
    { jp: ['セガ'], en: ['SEGA'] },
  ];

  // ===== 照合用の正規表現を事前構築 ================================
  const escapeRegExp = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  const japanesePatterns = JP_MAKERS.flatMap((maker) => maker.jp).map(escapeRegExp);
  const englishPatterns = JP_MAKERS.flatMap((maker) => maker.en).map(escapeRegExp);

  // 漢字・カナは部分一致。英字は前後が単語境界のときだけ一致。
  const japaneseRegex = japanesePatterns.length
    ? new RegExp(japanesePatterns.join('|'))
    : null;
  const englishRegex = englishPatterns.length
    ? new RegExp('(?:^|[^A-Za-z0-9])(?:' + englishPatterns.join('|') + ')(?![A-Za-z0-9])', 'i')
    : null;

  const isJapaneseMaker = (title) => {
    if (japaneseRegex && japaneseRegex.test(title)) return true;
    if (englishRegex && englishRegex.test(title)) return true;
    return false;
  };

  // Amazon が日本企業応援として一部商品に付ける公式ラベル「日本の中小企業」。
  // リストに無いメーカーでも、これがあれば日本企業として扱う（取りこぼし対策）。
  const SME_LABEL_TEXT = '日本の中小企業';
  const hasJapaneseSmeLabel = (card) => (card.textContent || '').includes(SME_LABEL_TEXT);

  // ===== バッジ・スタイル ==========================================
  const BADGE_CLASS = 'yamato-jp-badge';
  const badgeStyle = document.createElement('style');
  badgeStyle.textContent = `
    .${BADGE_CLASS} {
      display: inline-block;
      margin: 0 6px 4px 0;
      padding: 1px 6px;
      font-size: 12px;
      font-weight: 700;
      line-height: 1.4;
      color: #b00;
      border: 1px solid #b00;
      border-radius: 4px;
      background: #fff5f5;
      vertical-align: middle;
    }
  `;
  document.head.appendChild(badgeStyle);

  const addBadge = (item, labelText) => {
    const titleHeading = item.querySelector('h2');
    if (!titleHeading || titleHeading.querySelector('.' + BADGE_CLASS)) return;
    const badge = document.createElement('span');
    badge.className = BADGE_CLASS;
    badge.textContent = labelText;
    titleHeading.insertBefore(badge, titleHeading.firstChild);
  };

  // ===== 1商品の見た目を更新 ======================================
  const applyToItem = (item) => {
    const titleHeading = item.querySelector('h2');
    if (!titleHeading) return; // 見出しが無い枠（区切り等）は対象外

    // いったん装飾を初期化（前回のバッジを消してからタイトルを読む）
    item.style.opacity = '';
    item.style.display = '';
    const existingBadge = titleHeading.querySelector('.' + BADGE_CLASS);
    if (existingBadge) existingBadge.remove();

    if (!enabled) return; // OFF のときは素のAmazon表示

    const title = titleHeading.textContent || '';
    const matchedMaker = isJapaneseMaker(title);
    const matchedSme = hasJapaneseSmeLabel(item); // Amazon公式「日本の中小企業」ラベル

    if (matchedMaker || matchedSme) {
      if (mode === 'badge') addBadge(item, matchedMaker ? '日本メーカー' : '日本の企業');
      return;
    }
    // 日本企業と判定できないもの
    if (mode === 'hide') {
      item.style.display = 'none';
    } else {
      item.style.opacity = DIM_OPACITY;
    }
  };

  // ===== おすすめカルーセル（よく一緒に購入・関連商品 等） =================
  // 検索結果と違い、バッジ・非表示は行わず「薄く表示」だけにする
  // （横スクロールのカルーセルは非表示にすると隙間が空いて崩れるため）。
  // カルーセル/おすすめ枠のカードは複数系統ある：
  //   li.a-carousel-card             … 「よく一緒に購入」「チェックした人は…」等
  //   div[data-csa-c-type=item]      … 検索ページ等の新しい推薦枠（検索結果内部にも使われる）
  //   div.p13n-sc-uncoverable-faceout… RHF（閲覧履歴）「よく閲覧される商品」等のタイル
  // 検索結果内部や入れ子は後段で除外する。
  const CAROUSEL_CARD_SELECTOR =
    'li.a-carousel-card, div[data-csa-c-type="item"], div.p13n-sc-uncoverable-faceout';

  const getCarouselTitle = (card) => {
    const img = card.querySelector('img[alt]');
    const alt = img ? (img.getAttribute('alt') || '').trim() : '';
    if (alt.length > 4) return alt; // 商品名はだいたい画像の alt に入っている
    const linkWithTitle = card.querySelector('a[title]');
    return linkWithTitle ? (linkWithTitle.getAttribute('title') || '').trim() : '';
  };

  const applyToCarouselCard = (card) => {
    // メインの検索結果は別処理（バッジ/非表示）なので触らない
    if (card.closest('div[data-component-type="s-search-result"]')) return;
    // カードが入れ子のときは外側だけ処理（二重に薄くしない）
    if (card.parentElement && card.parentElement.closest(CAROUSEL_CARD_SELECTOR)) return;

    // 商品カードだけを対象にする（バナー・画像ギャラリー等は触らない）
    const isProductCard = card.querySelector('a[href*="/dp/"], a[href*="/gp/product"]');
    const title = getCarouselTitle(card);
    if (!isProductCard || !title) return;

    card.style.opacity = ''; // いったん戻してから判定を反映
    if (!enabled) return;
    if (!isJapaneseMaker(title) && !hasJapaneseSmeLabel(card)) card.style.opacity = DIM_OPACITY; // 日本企業以外だけ薄く
  };

  const processAll = () => {
    document.querySelectorAll('div[data-component-type="s-search-result"]').forEach((item) => {
      item.dataset[PROCESSED_FLAG] = '1';
      applyToItem(item);
    });
    document.querySelectorAll(CAROUSEL_CARD_SELECTOR).forEach(applyToCarouselCard);
  };

  // ===== 画面更新（ページ送り・遅延読み込み）に追従 ================
  let debounceTimer = null;
  const scheduleProcess = () => {
    if (debounceTimer) clearTimeout(debounceTimer);
    debounceTimer = setTimeout(processAll, OBSERVER_DEBOUNCE_MS);
  };

  const observer = new MutationObserver(scheduleProcess);
  observer.observe(document.body, { childList: true, subtree: true });

  // ===== 設定パネル（popup）との連携 ==============================
  // 保存済み設定を読み込んでから初回反映。以後の変更は監視して即時反映する。
  chrome.storage.local.get(DEFAULTS, (stored) => {
    enabled = stored.enabled;
    mode = stored.mode;
    processAll();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.enabled) enabled = changes.enabled.newValue;
    if (changes.mode) mode = changes.mode.newValue;
    processAll();
  });

  // ===== 初回実行（設定読込前でも既定値で一度反映） ===============
  processAll();
})();
